package com.assignment.android.weatherapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Searchable extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchable);
        final ProgressBar progress = findViewById(R.id.progress_circular);
        final TextView progressText = findViewById(R.id.loadingText);
        progress.setVisibility(View.VISIBLE);
        progressText.setVisibility(View.VISIBLE);

        // Get the intent, verify the action and get the query
        Intent intent = getIntent();
        final String query = intent.getStringExtra("ADDRESS");

        //toolbar displaying the current location searched with a back navigation arrow
        Toolbar searchToolbar = findViewById(R.id.search_toolbar);
        setSupportActionBar(searchToolbar);
        getSupportActionBar().setTitle(query);
        searchToolbar.setTitleTextColor(0xFFFFFFFF);
        assert getSupportActionBar() != null;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d("in searchable",query);
                //instantiating the default summary fragment
                Fragment summary = new summaryFragment(query); //pass the JSONObject response to the next fragment
                progress.setVisibility(View.INVISIBLE);
                progressText.setVisibility(View.INVISIBLE);
                //addToBackStack - to allow backward navigation
                getSupportFragmentManager().beginTransaction().replace(R.id.searchable_frame, summary, summary.getClass().getSimpleName()).addToBackStack(null).commit();
            }
        }, 4000);



    }//end of onCreate method


    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }


}//end of class Searchable

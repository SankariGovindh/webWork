package com.assignment.android.weatherapp;

import android.util.Log;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class FavPageAdapter extends FragmentPagerAdapter {

        private ArrayList<Fragment> mFragments = new ArrayList<>();
        private Set<String> placeList = new HashSet<String>();
        private long baseId = 0;

        public FavPageAdapter(FragmentManager fm)
        {
            super(fm,BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        //method to add the fragments - gets called in the mainActivity
        public void addFragment(Fragment fragment, String title)
        {
            if(!(placeList.contains(title))){
                Log.d("Logging the city in the fragment:",title);
                mFragments.add(fragment);
                placeList.add(title);
            }
        }

        //method to remove the fragments - gets called in the mainActivity
        public void removeFragment(int position){
            mFragments.remove(position);
            placeList.remove(position);
        }


        @Override
        public Fragment getItem(int position)
        {
            return mFragments.get(position);
        }

        @Override
        public int getCount() {
            Log.d("logging the count size:",String.valueOf(mFragments.size()));
            return mFragments.size();
        }

}

package com.assignment.android.weatherapp;

public class recycleView {
    private String imageUrl;

    public recycleView(String image){
        imageUrl = image;
    }//end of constructor

    public String getImageUrl(){
        return imageUrl;
    }//end of getter

}//end of class

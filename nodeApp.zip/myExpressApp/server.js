var express = require('express');
var http = require('http'); 
var request = require('request'); 
var https = require('https'); 
var url = require('url'); 
var cors = require('cors'); 
var app = express(); 
app.use(cors()); 

//declaring variable to be available to forecast and darksky API 
var latitude; 
var longitude; 

//creating functions to make call to the API on trigger 
app.get('/',function(req,res){
}); 

app.listen(8081, function () {
    console.log('Example app listening on port 3000!');
});


//extracting the data for the modal 
app.get('/darkSky_call',function(req,res){ 

    var incoming_url = req.url; 
    var query_string = incoming_url.split('?'); //splitting the query string from the incoming user query 
    params = query_string[1].split('&'); //params array containing latitude,longitude and time values 
    latitude = params[0].split("=")[1]; 
    longitude = params[1].split("=")[1]; 
    time = params[2].split("=")[1]; 
    
    var url_dark = "https://api.darksky.net/forecast/c40387792d1f698483de9ca1f3be72fb/"+latitude+","+longitude+","+time; 
 
  
    request(url_dark,function(error,response,dailyData){
        
        dailyJSON = dailyData; 
        return res.send(dailyJSON); 

    });//end of request

}); //end of function to call the darksky API 

app.get('/forecast_call',function(req,res){ 

    var url_string = req.url; 
    var params = url_string.split('?'); 
    console.log("params:",params); 
    var url = "https://maps.googleapis.com/maps/api/geocode/json?address="+params+"&key=AIzaSyCH2oPI34OIf0_qlzyL9zTIMfBUxEgZur4";
    console.log("url",url); 
    
    //calling the url to retrieve the latitude and longitude values 
    request(url,function(error,response,body){

        var data = JSON.parse(body); 
        latitude = data.results[0].geometry.location.lat; 
        longitude = data.results[0].geometry.location.lng; 
        var url_dark = "https://api.darksky.net/forecast/c40387792d1f698483de9ca1f3be72fb/"+latitude+","+longitude; 
        weatherJSON = request(url_dark,function(error,response,content){
               weatherJSON = content;
               return res.send(weatherJSON); 
        });               
    });       
}); //end of function to call foreCast API 

app.get('/cityPic',function(req,res){

    var state_url = req.url; 
    var state = state_url.split('?'); 
    var city = state_url.split('?'); //splitting the city value from the url 
    //var url = "https://www.googleapis.com/customsearch/v1?q=Seal of"+state+"&cx=000066031221280904308:rwmwns9ofxf&imgSize=huge&imgType=news&num=1&searchType=image&key=AIzaSyCH2oPI34OIf0_qlzyL9zTIMfBUxEgZur4"; 
    var url = "https://www.googleapis.com/customsearch/v1?q="+city+"&cx=000066031221280904308:1qngeof0co6&imgSize=large&searchType=image&key=AIzaSyCH2oPI34OIf0_qlzyL9zTIMfBUxEgZur4"; 

    request(url,function(error,response,body){

        stateJSON = body; 
        return res.send(stateJSON); 

    }); 

}); //end of function to call the retrieve state seal 

app.get('/autocomplete',function(req,res){

    var auto_url = req.url; 
    var city = auto_url.split('?'); 
    var url = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input="+city[1]+"&types=(cities)&language=en&key=AIzaSyCH2oPI34OIf0_qlzyL9zTIMfBUxEgZur4";

    request(url,function(error,response,body){

        cityJSON = body; 
        return res.send(cityJSON); 

    });//end of pulling the data 

});//end of function to pull values for the autocomplete field 

app.get('/currentLocationCall',function(req,res){

    var incoming_url = req.url; 
    var query_string = incoming_url.split('?'); //splitting the query string from the incoming user query 
    params = query_string[1].split('&'); //params array containing latitude,longitude 
    latitude = params[0].split("=")[1]; 
    longitude = params[1].split("=")[1];
    var url_dark = "https://api.darksky.net/forecast/c40387792d1f698483de9ca1f3be72fb/"+latitude+","+longitude; 
    weatherJSON = request(url_dark,function(error,response,content){
            weatherJSON = content;
            return res.send(weatherJSON); 
    }); //storing the weatherJSON details and returning for the current location              

}); //end of function to pull the weather details based on latitude and longitude 

app.get('/callGoogleAPI',function(req,res){

    var incoming_url = req.url; 
    var params= incoming_url.split('?'); 
    var google_call = "https://maps.googleapis.com/maps/api/geocode/json?address="+params+"&key=AIzaSyCH2oPI34OIf0_qlzyL9zTIMfBUxEgZur4"; 
    locationJSON = request(google_call,function(error,response,content){
        locationJSON = content;
        return res.send(locationJSON); 
    });

}); 

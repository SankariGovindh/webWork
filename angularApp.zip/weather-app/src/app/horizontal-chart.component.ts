import { Component,OnInit,ViewChild } from '@angular/core'; 
import * as CanvasJS from './canvasjs-2.3.2/canvasjs.min';
import { HttpService } from './http.service';
import { AppService } from './app.service';
import { ModalDirective } from 'ngx-bootstrap/modal'; 


    @Component({
        selector : 'hor-chart',
        templateUrl: './horizontal-chart.component.html'
    })

export class HorChartComponent implements OnInit{

    constructor(public httpService:HttpService,public dataService:AppService){}

    public weeklyData; 
    public latitude; public longitude; 
    public modalData; 
    public show:boolean = false; 
    public icon_url; 

    @ViewChild('autoShownModal', { static: false }) autoShownModal: ModalDirective;
    isModalShown = false;
    
    showModal(): void {
        this.isModalShown = true;
    }
    
    hideModal(): void {
        this.autoShownModal.hide();
    }
    
    onHidden(): void {
        this.isModalShown = false;
    }

    ngOnInit(){

        this.weeklyData = this.dataService.weeklyData; 
        this.latitude = this.weeklyData.latitude; 
        this.longitude = this.weeklyData.longitude; 
        var x = 10;
        var dataPoints = []; 
        for(var i=0; i<7; i++){
            dataPoints.push({
                x : x,  
                y: [this.weeklyData.tempLow[i],this.weeklyData.tempHigh[i]],
                label : this.weeklyData.time[i] 
            });
            x = x+10; 
        }//end of for loop 

        var chart = new CanvasJS.Chart("chartContainer", {
            animationEnabled: true,
            title: {
                text: "Weekly Weather"
            },
            axisX: {
                title: "Days"
            },
            axisY: {
                includeZero: false,
                title: "Temperature in Fahrenheit",
                interval: 10
            }, 
            data: [{
                type: "rangeBar",
                color : 'rgba(135,206,235,1)',
                showInLegend: true,
                dataPointWidth : 20,
                yValueFormatString: "#0.#",
                indexLabel: "{y[#index]}",
                legendText: "Day wise temperature range",
                toolTipContent: "<b>{label}</b>: {y[0]} to {y[1]}",
                dataPoints: dataPoints,
                click: (e) => { 
                    this.modalDisplay(e.dataPoint.label); //calling the function to set the data values 
                    this.showModal(); //set boolean value here
                 }
            }]
        });
        chart.render();
        
    }//end of ngOnInit 

    modalDisplay(time){
        this.httpService.getDailyModal(this.latitude,this.longitude,time).subscribe(dailyData =>{
            this.modalData = dailyData; 
        },
        
        (error) => console.log(error)
        ); //storing the dailyData returned by the backend API 

        //storing the icon value to display 
        if(this.modalData.currently.icon == "clear-day" || this.modalData.currently.icon == "clear-night"){
            this.icon_url = "https://cdn3.iconfinder.com/data/icons/weather-344/142/sun-512.png"; 
        }

        if(this.modalData.currently.icon == "rain"){
            this.icon_url = "https://cdn3.iconfinder.com/data/icons/weather-344/142/rain-512.png"; 
        }

        if(this.modalData.currently.icon == "snow"){
            this.icon_url = "https://cdn3.iconfinder.com/data/icons/weather-344/142/snow-512.png"; 
        }

        if(this.modalData.currently.icon == "sleet"){
            this.icon_url = "https://cdn3.iconfinder.com/data/icons/weather-344/142/lightning-512.png"; 
        }

        if(this.modalData.currently.icon == "wind"){
            this.icon_url = "https://cdn4.iconfinder.com/data/icons/the-weather-is-nice-today/64/weather_10-512.png"; 
        }

        if(this.modalData.currently.icon == "fog"){
            this.icon_url = "https://cdn3.iconfinder.com/data/icons/weather-344/142/cloudy-512.png"; 
        }

        if(this.modalData.currently.icon == "cloudy"){
            this.icon_url = "https://cdn3.iconfinder.com/data/icons/weather-344/142/cloud-512.png"; 
        }

        if(this.modalData.currently.icon == "partly-cloudy-day" || this.modalData.currently.icon == "partly-cloudy-night"){
            this.icon_url = "https://cdn3.iconfinder.com/data/icons/weather-344/142/sunny-512.png"; 
        }
    }//end of modalDisplay to call the backend and store the values 

}//end of class HorChartComponent 
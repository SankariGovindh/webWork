import { Routes, RouterModule } from '@angular/router'; 
import { AppComponent } from './app.component'
import { CurrentDataComponent } from './current-data.component'
import { BarChartComponent } from './barchart-data.component' 
import { HorChartComponent } from './horizontal-chart.component';
import { FavTabComponent } from './fav-tab.component';

const appRoutes: Routes = [
    {path:' ', component:AppComponent},
    { path: 'current', component:CurrentDataComponent},
    { path: 'hourly', component:BarChartComponent},
    { path:'weekly', component:HorChartComponent },
    { path:'fav', component:FavTabComponent }
]; 

export const routing = RouterModule.forRoot(appRoutes); 


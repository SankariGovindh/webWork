import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators'; 

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http: HttpClient) { }

  get(street,city,state){
    const getOptions = {
      params: { street:street, city:city, state:state }
    }; 
    const url = 'http://nodeapp571.us-west-1.elasticbeanstalk.com/forecast_call'; 
    return this.http.get(url, getOptions)
      .pipe(map(
        (response: Response) => {
          const data = response; 
          return data;          
      }));

  }//end of get - to read the weather data for the user input values 

  getSeal(state){
    const url_state ='http://nodeapp571.us-west-1.elasticbeanstalk.com/state_seal'; 
    return this.http.get(url_state, {params:state})
      .pipe(map(
        (response : Response) => {
          const data = response; 
          return data; 
      })); 
  }//end of receiving JSON for the state seal 

  getDailyModal(latitude,longitude,time){
    const getOptions = {
      params : {latitude:latitude, longitude:longitude, time:time}
    };
    const url = 'http://nodeapp571.us-west-1.elasticbeanstalk.com/darkSky_call'; 
    return this.http.get(url, getOptions)
      .pipe(map(
        (response:Response) => {
          const dailyData = response; 
          return dailyData; 
      })); 
  }//end of getDailyModal

  getCurrentWeatherData(latitude,longitude){
    console.log("in getCurrentWeatherData call"); 
    const getOptions = {
      params : {latitude:latitude,longitude:longitude}
    }; 

    const url = "http://nodeapp571.us-west-1.elasticbeanstalk.com/currentLocationCall"; 
    return this.http.get(url, getOptions)
      .pipe(map(
        (response:Response) => {
          const currentLocationData = response; 
          return currentLocationData; 
        }));

  }//end of getCurrentWeatherData 

  getIpApi(){

    const url = "http://ip-api.com/json"; 
    return this.http.get(url)
    .pipe(map(
      (response:Response) => {
         const locationDetails = response; 
         return locationDetails; 
      })); 

  }//end of getIpApi 

}//end of class 

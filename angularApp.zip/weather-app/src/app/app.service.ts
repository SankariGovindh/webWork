import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  currentData; 
  hourData; tempArray = new Array(); pressArray = new Array(); humArray = new Array(); ozArray = new Array(); visArray = new Array(); winArray = new Array(); 
  weeklyData; timeArray = new Array(); tempLowArray = new Array(); tempHighArray = new Array(); 
  localData; 

  constructor() { }
  
                                                //storing and retrieving the current data 

  public currentFlag:boolean = false; 
                                                
  storeCurrentData(weatherData,city,stateData){

    //accessing the JSON values and storing in currentData for the current tab 
    this.currentData = {
      city : city, 
      timezone : weatherData.timezone,
      temperature : Math.round(weatherData.currently.temperature),
      summary : weatherData.currently.summary, 
      humidity : weatherData.currently.humidity,
      pressure : weatherData.currently.pressure,
      windspeed : weatherData.currently.windSpeed, 
      visibility : weatherData.currently.visibility,
      cloudcover : weatherData.currently.cloudCover,
      ozone : weatherData.currently.ozone,
      stateSeal : stateData.items[0].link
    } 

    this.currentFlag = true;

}//end of storeData

  retrieveCurrentData(){ 
    return this.currentData; 
  }//end of retrieveData 

                                                        //storing and retreiving 24 hours data 

  storeHourlyData(weatherData){

    //storing 24 temperature values 
    for(let i=0;i<24;i++){
      this.tempArray.push(weatherData.hourly.data[i].temperature); 
    } 

    //storing 24 pressure values 
    for(let i=0;i<24;i++){
      this.pressArray.push(weatherData.hourly.data[i].pressure); 
    }

    //storing 24 humidity values 
    for(let i=0;i<24;i++){
      this.humArray.push(weatherData.hourly.data[i].humidity); 
    }

    //storing 24 ozone values
    for(let i=0;i<24;i++){
      this.ozArray.push(weatherData.hourly.data[i].ozone); 
    }

    //storing 24 visibility values 
    for(let i=0;i<24;i++){
      this.visArray.push(weatherData.hourly.data[i].visibility); 
    }

    //storing 24 wind speed values 
    for(let i=0;i<24;i++){
      this.winArray.push(weatherData.hourly.data[i].windSpeed); 
    }

    this.hourData = {
      temperature : this.tempArray,
      pressure : this.pressArray,
      humidity : this.humArray, 
      ozone : this.ozArray, 
      visibility : this.visArray, 
      windspeed : this.winArray       
    }

  }//end of storeData 

  retrieveHourlyData(){
    return this.hourData; 
  }//end of retrieveHourData   

                                                    //storing and retrieving the weekly data for temperature

  storeWeeklyData(weatherData,city){

    //storing the date value 
    for(let i=0;i<weatherData.daily.data.length;i++){
      this.timeArray.push(weatherData.daily.data[i].time); //yet to convert the time to date format 
    }

    for(let i=0;i<weatherData.daily.data.length;i++){
      this.tempLowArray.push(weatherData.daily.data[i].temperatureLow); 
    }

    for(let i=0;i<weatherData.daily.data.length;i++){
      this.tempHighArray.push(weatherData.daily.data[i].temperatureHigh); 
    }

    this.weeklyData = {
      city : city, 
      time : this.timeArray,
      tempLow : this.tempLowArray,
      tempHigh : this.tempHighArray,
      latitude : weatherData.latitude,
      longitude : weatherData.longitude
    }

  }//end of storeWeeklyData          
  
  retrieveWeeklyData(){
    return this.weeklyData; 
  }


}//end of class AppService 

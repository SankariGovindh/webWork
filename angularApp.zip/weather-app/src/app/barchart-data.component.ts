import { Component, OnInit } from '@angular/core';
import { AppService }  from './app.service'; 
import { ChartOptions,ChartType,ChartDataSets } from 'chart.js'; 
import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Label } from 'ng2-charts'; 
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './barchart-data.component.html',
})
export class BarChartComponent implements OnInit {

  public hourData;   
  public tempoArray; 
  public chartReady:boolean = false; 
  public value; 
  public barChartOptions; public barChartLabels; public barChartType; public barChartLegend; public barChartData; 

  dataArray = ["Temperature","Pressure","Humidity","Ozone","Visibility","Wind Speed"]; 

  constructor(private dataService:AppService) { }//end of constructor
 

  ngOnInit(){

      //reading the values from the app service 
      this.hourData = this.dataService.retrieveHourlyData();

      //initially display the temperature graph
      this.barChartOptions = {
        scaleShowVerticalLines: false,
        responsive: true,
        legend: {
          onClick: (e) => e.stopPropagation()
        },
        scales:{
          xAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Time difference from current hour'
            }
          }],
          yAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Fahrenheit'
            }
          }]
        }
      };
      this.barChartType = 'bar';
      this.barChartLegend = true; 
      this.barChartData[0].label = 'temperature';
      this.barChartData[0].backgroundColor = 'rgba(135,206,235,1)';
      this.barChartData[0].hoverBackgroundColor = 'rgb(0,191,255)';
      this.barChartData[0].hoverBorderColor ='rgba(135,206,235,1)'; 
      this.barChartLabels = ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
      this.barChartData[0].data = this.hourData.temperature; 
      console.log("from ngOnInit ready"); 
      this.chartReady = true ; 

  }//end of ngOnInit 

  sendValue(value){
    this.value = value; 

    if(this.value=="Temperature"){   
        
      this.barChartOptions = {
        scaleShowVerticalLines: false,
        responsive: true,
        legend: {
          onClick: (e) => e.stopPropagation()
        },
        scales:{
          xAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Time difference from current hour'
            }
          }],
          yAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Fahrenheit'
            }
          }]
        }
      };
      this.barChartType = 'bar';
      this.barChartLegend = true; 
      this.barChartData[0].label = 'temperature';
      this.barChartData[0].backgroundColor = 'rgba(135,206,235,1)';
      this.barChartData[0].hoverBackgroundColor = 'rgb(0,191,255)';
      this.barChartData[0].hoverBorderColor ='rgba(135,206,235,1)'; 
      this.barChartLabels = ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
      this.barChartData[0].data = this.hourData.temperature;       
    }//end of if Temperature

    if(this.value=="Pressure"){
      this.barChartOptions = {
        scaleShowVerticalLines: false,
        responsive: true,
        legend: {
          onClick: (e) => e.stopPropagation()
        },
        scales:{
          xAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Time difference from current hour'
            }
          }],
          yAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Millibars'
            }
          }]
        }
      };
      this.barChartType = 'bar';
      this.barChartLegend = true; 
      this.barChartData[0].label = 'pressure';
      this.barChartData[0].backgroundColor = 'rgba(135,206,235,1)';
      this.barChartData[0].hoverBackgroundColor = 'rgb(0,191,255)';
      this.barChartData[0].hoverBorderColor ='rgba(135,206,235,1)'; 
      this.barChartLabels = ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
      this.barChartData[0].data = this.hourData.pressure;  
    }

    if(this.value=="Humidity"){
      this.tempoArray = new Array(); 
      this.tempoArray.push(this.hourData.humidity); 
      console.log("humidity:",this.tempoArray); 
      this.barChartOptions = {
        scaleShowVerticalLines: false,
        responsive: true,
        legend: {
          onClick: (e) => e.stopPropagation()
        },
        scales:{
          xAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Time difference from current hour'
            }
          }],
          yAxes:[{
            scaleLabel:{
              display:true,
              labelString: '% Humidity'
            }
          }]
        }
      };
      this.barChartLabels = ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
      this.barChartType = 'bar';
      this.barChartLegend = true; 
      this.barChartData = [
        {data: [0.82,0.82,0.85,0.87,0.9,0.92,0.92,0.92,0.91,0.9,0.9,0.9,0.91,0.86,0.74,0.68,0.61,0.56,0.53,0.54,0.57,0.61,0.66,0.71], label: 'humidity',backgroundColor : 'rgba(135,206,235,1)',hoverBackgroundColor:'rgb(0,191,255)',hoverBorderColor:'rgba(135,206,235,1)'}
      ];
    }

    if(this.value=="Ozone"){
      this.tempoArray = new Array(); 
      this.tempoArray.push(this.hourData.ozone); 
      console.log("ozone:",this.tempoArray); 
      this.barChartOptions = {
        scaleShowVerticalLines: false,
        responsive: true,
        legend: {
          onClick: (e) => e.stopPropagation()
        },
        scales:{
          xAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Time difference from current hour'
            }
          }],
          yAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Dobson Units'
            }
          }]
        }
      };
      this.barChartLabels = ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
      this.barChartType = 'bar';
      this.barChartLegend = true; 
      this.barChartData = [
        {data: [279.9,280.5,281,281.6,282.8,284.3,285.3,285,284.1,283.7,283.9,284.6,285.3,285.7,286,286.3,286.4,286.4,286.7,287.8,289.2,290.2,290.5,290.5], label: 'ozone',backgroundColor : 'rgba(135,206,235,1)',hoverBackgroundColor:'rgb(0,191,255)',hoverBorderColor:'rgba(135,206,235,1)'}
      ];
    }

    if(this.value=="Visibility"){
      this.tempoArray = new Array(); 
      this.tempoArray.push(this.hourData.visibility); 
      console.log("visibility:",this.tempoArray); 
      this.barChartOptions = {
        scaleShowVerticalLines: false,
        responsive: true,
        legend: {
          onClick: (e) => e.stopPropagation()
        },
        scales:{
          xAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Time difference from current hour'
            }
          }],
          yAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Miles(Maximum 10)'
            }
          }]
        }
      };
      this.barChartLabels = ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
      this.barChartType = 'bar';
      this.barChartLegend = true; 
      this.barChartData = [
        {data:[8.981,9.582,10,10,10,10,10,9.781,9.569,9.396,10,8.983,9.457,10,10,10,10,10,10,10,10,10,10,10], label: 'visibility',backgroundColor : 'rgba(135,206,235,1)',hoverBackgroundColor:'rgb(0,191,255)',hoverBorderColor:'rgba(135,206,235,1)'}
      ];
    }

    if(this.value=="Wind Speed"){
      this.tempoArray = new Array(); 
      this.tempoArray.push(this.hourData.windspeed); 
      console.log("wind:",this.tempoArray); 
      this.barChartOptions = {
        scaleShowVerticalLines: false,
        responsive: true,
        legend: {
          onClick: (e) => e.stopPropagation()
        },
        scales:{
          xAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Time difference from current hour'
            }
          }],
          yAxes:[{
            scaleLabel:{
              display:true,
              labelString: 'Miles per Hour'
            }
          }]
        }
      };
      this.barChartLabels = ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
      this.barChartType = 'bar';
      this.barChartLegend = true; 
      this.barChartData = [
        {data: [2.65,2.15,2.54,3.39,3.3,3,3.23,2.66,2.11,2.25,2.55,1.92,2.1,2.06,1.96,2.21,2.89,4,4.76,5.31,5.63,5.34,4.5,3.24] , label: 'windSpeed',backgroundColor : 'rgba(135,206,235,1)',hoverBackgroundColor:'rgb(0,191,255)',hoverBorderColor:'rgba(135,206,235,1)'}
      ];
    }

  }//end of send value 

}//end of class 





















/*import { Component, OnInit } from '@angular/core'; 
import { ChartOptions,ChartType,ChartDataSets } from 'chart.js'; 
import * as pluginDataLabels from 'chartjs-plugin-datalabels'; 
import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Label } from 'ng2-charts'; 
import { AppService } from './app.service';

@Component({
    selector:'app-bar-data',
    templateUrl: './barchart-data.component.html'
})

export class BarChartComponent implements OnInit {   
  
  hourData; 
  chartReady:boolean = false; 

  constructor(private dataService:AppService) { }
  ngOnInit(){
      this.hourData = this.dataService.retrieveHourlyData();  
  }

  public barChartOptions: ChartOptions = {
    responsive : true, 
    scales: { xAxes:[{}], yAxes : [{}] },
    
  };

  public barChartData = [ {data:[59.6, 58.63, 58.35, 58.09, 57.65, 57.23, 56.82, 56.58, 56.46, 56.29, 56, 55.19, 55.19, 57.67, 61.11, 63.92, 66.6, 68.84, 70.06, 69.81, 68.54, 66.66, 64.52, 62.46],
    label : 'temperature',
    backgroundColor : 'rgba(135,206,235,1)', 
    xAxisID : 'Time', 
    yAxisID : 'Farenheit' }]; 
  public barChartLabels: Label[] = ['0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  value; 


  /*chartData(value){
    this.value = value;  
    if(this.value == "Temperature"){
 
    }//end of temperature if 

    if(this.value=="Pressure"){
      //looping through the JSON values to store all in barchartData array 
      this.barChartData.data  = this.hourData.pressure; 
      this.barChartData.label = 'pressure'; 
      this.barChartData.backgroundColor = 'rgba(0,0,0,0.1)';
      this.barChartData.xAxisID = 'Time'; 
      this.barChartData.yAxisID = 'Milliseconds'; 
    }//end of pressure if

    if(this.value=="Humidity"){
      //looping through the JSON values to store all in barchartData array 
      this.barChartData.data  = this.hourData.humidity; 
      this.barChartData.label = 'humidity'; 
      this.barChartData.backgroundColor = 'rgba(0,0,0,0.1)';
      this.barChartData.xAxisID = 'Time'; 
      this.barChartData.yAxisID = '% Humidity'; 
    }//end of humidity if 

    if(this.value=="Ozone"){
      //looping through the JSON values to store all in barchartData array 
      this.barChartData.data  = this.hourData.ozone; 
      this.barChartData.label = 'ozone'; 
      this.barChartData.backgroundColor = 'rgba(0,0,0,0.1)';
      this.barChartData.xAxisID = 'Time'; 
      this.barChartData.yAxisID = 'Dobson Units'; 
    }//end of ozone if 

    if(this.value=="Visibility"){
      //looping through the JSON values to store all in barchartData array 
      this.barChartData.data  = this.hourData.visibility; 
      this.barChartData.label = 'visibility'; 
      this.barChartData.backgroundColor = 'rgba(0,0,0,0.1)';
      this.barChartData.xAxisID = 'Time'; 
      this.barChartData.yAxisID = 'Miles(Maximum 10)'; 
    }//end of ozone if 

    if(this.value=="Wind Speed"){
      //looping through the JSON values to store all in barchartData array 
      this.barChartData.data  = this.hourData.windspeed; 
      this.barChartData.label = 'wind speed'; 
      this.barChartData.backgroundColor = 'rgba(0,0,0,0.1)';
      this.barChartData.xAxisID = 'Time'; 
      this.barChartData.yAxisID = 'Miles per hour'; 
    }//end of ozone if 

  }//end of chartData */

//}//end of class barchart

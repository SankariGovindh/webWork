import { Component,Input } from '@angular/core'; 
import { ActivatedRoute } from '@angular/router'; 
import { AppService } from './app.service';

@Component({
    selector: 'app-current-data',
    templateUrl: './current-data.component.html'
})

export class CurrentDataComponent {
    currentData; 

    constructor(private dataService:AppService){ 

        if(this.dataService.currentFlag){

            this.currentData = this.dataService.retrieveCurrentData(); 
            console.log("currentData:",this.currentData);

        }        
    }

    ngOnInit() { 
    }
     
}
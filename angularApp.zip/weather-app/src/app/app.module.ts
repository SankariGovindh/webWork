import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'; 
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { BarChartComponent } from './barchart-data.component'; 
import { CurrentDataComponent } from './current-data.component'; 
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'; 
import { ChartsModule } from 'ng2-charts'; 
import { routing } from './app.routing'; 
import { HorChartComponent } from './horizontal-chart.component'; 
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { ModalModule } from "ngx-bootstrap";
import { FavTabComponent } from './fav-tab.component'; 
import { MatAutocompleteModule,MatSelectModule,MatFormFieldModule } from '@angular/material';

@NgModule({
    imports: [
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        ChartsModule,
        FormsModule,
        NgbModule,
        routing,
        BrowserAnimationsModule,
        ModalModule.forRoot(),
        MatAutocompleteModule,
        MatSelectModule,
        MatFormFieldModule
    ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
    declarations: [AppComponent,CurrentDataComponent,BarChartComponent,HorChartComponent,FavTabComponent],
    bootstrap: [AppComponent]
})

export class AppModule {}

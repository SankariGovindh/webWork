import { Component,OnInit } from '@angular/core';
import { FormGroup,FormControl,Validators } from '@angular/forms'; 
import { HttpService } from './http.service'
import { AppService } from './app.service'
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators'; 
 

function content(city,temp,summary){
  var params= "The current temperature at " +city+ " is " +temp+ " F. The weather conditions are " +summary+ ".      CSCI571WeatherSearch"; 
  var url = "https://twitter.com/intent/tweet?text="+params;
  var element = document.getElementById('tweet');
  element.setAttribute("href",url)         
}//end of content 


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})

export class AppComponent implements OnInit {
  form: FormGroup; 
  public weatherData; 
  json_fav; keys; stateData; 
  street; city; state;
  public progress:boolean = false; 
  public tab:boolean = false; 
  public record:boolean = false; 
  public showFirst:boolean = true; 
  public locationDetails; public latitude; public longitude; 
  public localData; public showFav:boolean = false; public info:boolean = false; 
 

  constructor(private httpService:HttpService,private dataService:AppService,private http: HttpClient){}

  ngOnInit(): void {    
    this.form = new FormGroup({
      street: new FormControl('', Validators.required),
      city: new FormControl('', Validators.required),
      state: new FormControl('', Validators.required)
    });    
  }

  progress_bar(){
    this.progress = !this.progress; 

    //calling js function to display the correct block - testing : later move after data obtained 
    setInterval(() => {this.validation(this.weatherData);},3000); 

  }//end of progress_bar

  validation(temperature){
    if(temperature){
      this.progress = false; 
      this.tab = true;   
    }//displaying the nav tab if record is valid 

    else{
      this.progress = false; 
      this.record = true;
    }//displaying error message if invalid 

  }//end of validation 

                                              //weatherData storage and retrieval when user input data in form 

  onSubmit(value){

    if(value.street){
      this.street = value.street; 
      this.city = value.city; 
      this.state = value.state;   

      //calling the progress function to display the progress bar 
      this.progress_bar(); 
      //making HTTP request to the backend to get the details
      this.getWeatherData(this.street,this.city,this.state); 
    }//end of if 
    
    else{ 
      this.onChecked(); 
    }//current location selected 

  }//end of onSubmit


  getWeatherData(street,city,state){
    this.httpService.get(street,city,state).subscribe(data => {
        this.weatherData = data;   
      },
      (error) => console.log(error)  
    ); //storing the JSON value in weatherData var 

    this.httpService.getSeal(state).subscribe(statedata => {
        this.stateData = statedata; 
    });
  
    this.dataService.storeCurrentData(this.weatherData,city,this.stateData); 
    this.dataService.storeHourlyData(this.weatherData); 
    this.dataService.storeWeeklyData(this.weatherData,city);  

  }//end of getWeatherData

  //get getWeatherData for the current location 

                                                  //weatherData storage when current location is checked

  onChecked(){

    //calling the progress function to display the progress bar 
    this.progress_bar(); 

    //calling the ip-api 
    this.httpService.getIpApi().subscribe(locationDetails => {
      this.locationDetails = locationDetails; 
    });

    this.latitude = this.locationDetails.lat; 
    this.longitude = this.locationDetails.lon; 
    this.city = this.locationDetails.city; 
    this.state = this.locationDetails.region; 
    console.log("latitude:",this.latitude); 
    console.log("longitude:",this.longitude); 

    //calling the darkSky API to read the weather data 
    this.httpService.getCurrentWeatherData(this.latitude,this.longitude).subscribe(data => {
      this.weatherData = data;   
    }, 
    (error) => console.log(error) 
    ); //storing the JSON value of the current location's weather 

    this.httpService.getSeal(this.state).subscribe(statedata => {
        this.stateData = statedata; 
    });

    this.dataService.storeCurrentData(this.weatherData,this.city,this.stateData); 
    this.dataService.storeHourlyData(this.weatherData); 
    this.dataService.storeWeeklyData(this.weatherData,this.city); 

  }//end of onChecked function 

                                            //handling onclick of tweet icon 

  //below call is to display custom message on click of the twitter button 
  contentCall(){
    content(this.city,this.weatherData.currently.temperature,this.weatherData.currently.summary); 
  }

                                            //handling the favorites tab 

  //switching icons and passing the values to the fav-local component to store the values in the local storage 
  favToggle(){     

    if(!localStorage.getItem(this.city))
    {
        this.showFirst = !this.showFirst; //setting the fav icon
        this.localData = {
          seal : this.stateData.items[0].link, 
          city : this.city, 
          state : this.state,
          latitude : this.weatherData.latitude,
          longitude : this.weatherData.longitude
        }
        localStorage.setItem(this.city,JSON.stringify(this.localData)); //setting the localdata    
    }//if value already not present then store the value   
    
    else{
      //show the city is already in favorites 
      this.showFirst = !this.showFirst; 
    }

  }//end of favToggle - setting value for the local storage 
  
  favDisplay(){
    this.tab = false; //hiding the tab and the display below 
    //this.showFav = true; //showing only the fav-tab component output 
  }

  //on click of clear button 
  clearAll(){
    this.tab = false; 
    this.progress = false; 
    this.showFav = false; 
  }

  getAutoSuggest(key) {
    const url = '/autocomplete?keyword=' +  key;
    console.log(this.http.get(url)); 
    return this.http.get(url);
  }
    

}//end of app component class 

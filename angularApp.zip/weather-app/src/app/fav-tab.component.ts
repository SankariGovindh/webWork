import { Component,OnInit, ɵLocaleDataIndex } from '@angular/core'; 
import { AppService } from './app.service';

@Component({
    selector : 'fav-tab', 
    templateUrl : './fav-tab.component.html'
})


export class FavTabComponent {

    public showFav : boolean = false; 
    public info : boolean = false; 
    public favList = []; 

    constructor(private dataService:AppService){}

    ngOnInit(){

        if (localStorage.length)
        {
            this.showFav = true; 
            for(let key in localStorage)
            {
                if(localStorage.getItem(key)){
                    this.favList.push(JSON.parse(localStorage.getItem(key)));
                }
                
                
            }
            console.log("list:",this.favList);        
        }//end of if 
        
        else{
            this.info = true; 
        }

    }//storing data 

    //removing the item from the particular index in localstorage and decrementing the index value 
    removeFavorite(city){
        localStorage.removeItem(city)
    }

    //backend call to pull the api results 
    apicall(){
        console.log("in api call"); 
    }

}//end of class 